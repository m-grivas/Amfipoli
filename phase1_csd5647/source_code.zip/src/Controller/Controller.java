package Controller;

import Model.Model;

public class Controller {

    private final Model model;

    public Controller(Model m) {
        this.model = m;
    }


    /**
     * Initializes Model and View
     * @param playerCount: how many players are playing the game
     */
    public void startGame(int playerCount) {
        model.initializeGame(playerCount);
    }


    /**
     * When player draws tiles
     */
    public void onDrawTiles() {}

    /**
     * When player presses the End Turn button, end his turn and move to the next player
     */
    public void onEndTurn() {}

    /**
     * When player presses a board area, select tiles from this area
     */
    public void onBoardAreaClicked() {}

    /**
     * Capability to move inventory items by dragging them and maybe unite them(experimental)
     */
    public void onInventoryItemClicked() {}

    /**
     * When player clicks a character use the characters ability
     */
    public void onCharacterClicked() {}

    /**
     * When user clicks New Game button, end the game and start a new one
     */
    public void onNewGame() {}

    /**
     * When user presses the Save button, save the game to a saved file and go to starting screen
     */
    public void onSave() {}

    /**
     * When user presses Load button, load a saved game from the saved file
     */
    public void onLoad() {}

    /**
     * When user presses the exit button exit the game
     */
    public void onExit() {}


    /**
     * Main game function that continues running while there is not a winner yet<br>
     * - Gets the player who plays from Model.whoPlays()<br>
     * - Does the required actions for the players turn<br>
     * - Updates accordingly the GUI<br>
     * - Checks if any other button has been pressed and acts accordingly
     */
    public void gameLoop() {}

    /**
     * Check if there is a winner so the game has ended
     */
    public void checkForWinner() {}



    //Utility functions

    /**
     * Reads from the user the number of the players
     * @return the number of players
     */
    public int getPlayerCount() {
        return 0;
    }

    /**
     * Reads from the user the player name
     * @return: the players name
     */
    public String getPlayerName() {
        return "";
    }

}
