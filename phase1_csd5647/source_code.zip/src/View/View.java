package View;

import Controller.Controller;
import Model.Board;
import Model.Player;
import Model.TurnTimer;

import javax.swing.*;

public class View extends JFrame implements ViewInterface {

    private Controller controller;

    private JLabel currentPlayerLabel;
    private JButton drawTilesButton;
    private JButton endTurnButton;


    @Override
    public void setController(Controller controller) {

    }

    @Override
    public void showStartingScreen() {

    }

    @Override
    public void showBoard(Board board) {

    }

    @Override
    public void showCurrentPlayer(Player player) {

    }

    @Override
    public void showInventory(Player player) {

    }

    @Override
    public void showCharacters(Player player) {

    }

    @Override
    public void showTimer(TurnTimer timer) {

    }

    @Override
    public void showWinnerScreen(Player[] player) {

    }
}
