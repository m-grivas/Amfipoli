package View;

import Model.Player;

import javax.swing.*;

public class InventoryPanel extends JFrame {

    private Player player;

    /**
     * Constructor that initializes the player to show his inventory
     * @param p: the player object
     */
    public InventoryPanel(Player p) {
        player = p;
    }


    /**
     * Setter for the player
     * @param p: the new player
     */
    public void setPlayer(Player p) {
        player = p;
    }

    @Override
    public void repaint() {}





}
