package View;

import Model.Player;
import Model.TurnTimer;

import javax.swing.*;

public class PlayerPanel extends JFrame {

    private Player player;
    private TurnTimer timer;

    private JLabel time;
    private JLabel playerName;

    private CharacterPanel characterPanel;

    private JButton drawTilesButton;
    private JButton endTurnButton;


    /**
     * Constructor for PlayerPanel
     * @param p:Player object
     * @param t: TurnTime object
     * @param c: CharacterPanel object
     */
    public PlayerPanel(Player p, TurnTimer t, CharacterPanel c) {
        player = p;
        timer = t;
        characterPanel = c;
    }


    /**
     * Setter for the player
     * @param p: the new Player object
     */
    public void setPlayer(Player p) {
        player = p;
    }


    @Override
    public void repaint() {}



}
