package View;

import Controller.Controller;
import Model.Board;
import Model.Player;
import Model.TurnTimer;

public interface ViewInterface {
    /**
     * Setter for the Controller
     * @param controller: controller object
     */
    void setController(Controller controller);


    /**
     * Show starting screen that asks user for the players count
     */
    void showStartingScreen();

    /**
     * Show the game board with its areas
     * @param board: the game board
     */
    void showBoard(Board board);

    /**
     * Show the current player and his color
     * @param player: current player
     */
    void showCurrentPlayer(Player player);

    /**
     * Show the current players inventory
     * @param player: current player
     */
    void showInventory(Player player);

    /**
     * Show the players available characters<br>
     * If a character's ability is used the character card is displayed in gray color
     * @param player
     */
    void showCharacters(Player player);

    /**
     * Show the time the player has left
     * @param timer: the timer object
     */
    void showTimer(TurnTimer timer);



    /**
     * When the game ends display a scoreboard with the points of all players
     * @param players: the list of all players
     */
    void showWinnerScreen(Player[] players);
}
