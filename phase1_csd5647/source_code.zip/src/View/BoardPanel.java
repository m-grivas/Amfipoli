package View;

import Model.Board;

import javax.swing.*;
import java.awt.*;

public class BoardPanel extends JPanel {

    private Board board;
    private Image backgroundImage;
    private Rectangle[] areaBounds;


    /**
     * Initialize BoardPanel with background image and area bounds
     */
    public BoardPanel() {

    }

    /**
     * Setter for the board
     * @param b: the new board
     */
    public void setBoard(Board b) {
        board = b;
    }



    /**
     * Function to repaint board after changes
     */
    @Override
    public void repaint() {

    }

}
