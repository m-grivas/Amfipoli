package View;

import Model.Player;

import javax.swing.*;

public class CharacterPanel extends JFrame {

    private Player player;


    /**
     * Constructor
     * @param p: the new player
     */
    public CharacterPanel(Player p) {
        player = p;
    }


    /**
     * Setter for player
     * @param p: the new player
     */
    public void setPlayer(Player p) {
        player = p;
    }

    @Override
    public void repaint() {}




}
