package Model.Tiles;
import Model.Color;
import Model.Colored;

public class AmphoraTile extends FindingTile implements Colored {
    private Color color;

    @Override
    public Color getColor() {return this.color;}

    @Override
    public void setColor(Color c) {this.color = c;}

}
