package Model.Tiles;

public class SkeletonTile extends FindingTile {

    /**
     * The type of the Skeleton Tile
     */
    private SkeletonType type;

    /**
     * Construct a new skeleton tile with type t
     * @param t: the type of the new skeleton
     */
    public SkeletonTile(SkeletonType t) {
        this.type = t;
    }


    /**
     * Enumeration for the different SkeletonTile types
     */
    public enum SkeletonType {
        ADULT_UPPER,
        ADULT_LOWER,
        CHILDREN_UPPER,
        CHILDREN_LOWER
    }
}
