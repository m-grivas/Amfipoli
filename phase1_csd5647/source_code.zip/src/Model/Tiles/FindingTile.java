package Model.Tiles;

public abstract class FindingTile extends Tile {
}
