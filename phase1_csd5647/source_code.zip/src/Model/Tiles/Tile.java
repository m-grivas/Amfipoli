package Model.Tiles;

public abstract class Tile {
}
