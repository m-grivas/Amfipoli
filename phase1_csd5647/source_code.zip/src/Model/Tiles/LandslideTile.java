package Model.Tiles;


public class LandslideTile extends Tile {
}
