package Model.Tiles;

import Model.Color;
import Model.Colored;

public class MosaicTile extends FindingTile implements Colored {
    /**
     * The color of the Mosaic Tile
     */
    private Color color;

    @Override
    public Color getColor() {
        return this.color;
    }

    @Override
    public void setColor(Color c) {
        this.color = c;
    }
}
