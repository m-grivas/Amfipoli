package Model;

import Model.Characters.Character;
import Model.Tiles.Tile;
import Model.Characters.*;

import java.util.ArrayList;
import java.util.List;

public class Player implements Colored {
    private String name;
    private Color color;

    private List<Tile> invetory;
    private Character[] characters;


    /**
     * Initialize player with empty inventory and all 5 characters
     * @param c: the color of the new player
     * @param n: the name of the new player
     */
    public Player(Color c, String n) {
        color = c;
        name = n;
        invetory = new ArrayList<>();
        characters = new Character[5];

        characters[0] = new Assistant(c);
        characters[1] = new Archeologist(c);
        characters[2] = new Digger(c);
        characters[3] = new Professor(c);
        characters[4] = new Coder(c);

    }

    /**
     * Getter for the name
     * @return player name
     */
    public String getName() {
        return this.name;
    }



    /**
     * Function to pick 4 random tiles from the bag and add them to the corresponding board areas
     */
    public void pickTilesFromBag() {}


    /**
     * Pick up to 2 tiles from a boards area and add them to inventory
     */
    public void pickTilesFromBoard() {}


    /**
     * Function to use the ability of an available character
     * @param c: the character to be used
     */
    public void useCharacter(Character c) {}


    /**
     * Function to calculate the players points according to his inventory
     * @return the points of the player
     */
    public int calculatePoints() {return 0;}


    @Override
    public Color getColor() {
        return null;
    }

    @Override
    public void setColor(Color c) {

    }



}
