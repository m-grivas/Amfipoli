package Model;

import java.util.Timer;
import java.util.TimerTask;

public class TurnTimer {

    private Timer timer;

    /**
     * Start a 30 seconds timer for each player turn
     */
    public void start() {}

    /**
     * Stop the timer when the player played
     */
    public void stop() {}


}
