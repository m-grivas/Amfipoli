package Model;

import java.io.File;

public class MusicPlayer {

    /**
     * Play music from a wav file
     * @param musicFile: the .wav file that contains the music
     */
    public void playMusicFile(File musicFile) {}
}
