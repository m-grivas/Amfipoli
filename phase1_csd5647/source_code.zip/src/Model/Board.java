package Model;

import Model.Tiles.*;

public class Board {
    private MosaicTile[] mosaicArea = new MosaicTile[27];

    private StatueTile[] statueArea = new StatueTile[24];

    private AmphoraTile[] amphoraArea = new AmphoraTile[30];

    private SkeletonTile[] skeletonArea = new SkeletonTile[30];

    /**
     * Initializes Board
     */
    public Board() {

    }

    /**
     * Appends a tile to the corresponding area
     * @param t: the tile to append
     */
    public void appendTileToArea(Tile t) {;}

    //TODO add getters

    //check if entry is blocked
}
