package Model;

public class Model {

    private Player[] players;
    private Board board;
    private Bag bag;


    /**
     * Function to initialize Game<br>
     * - Initializes Bag and the tiles in it by calling Bag()<br>
     * - Initializes Board<br>
     * - Initializes players with colors<br>
     * - Gives character cards to players according to their color<br>
     * - Places a tile from each category to the corresponding board area<br>
     * - Chooses randomly the player to play first<br>
     * @param player_count: the number of the players
     */
    public void initializeGame(int player_count) {

        players = new Player[player_count];



    }


    //getters:

    public Board getBoard() {
        return board;
    }
    public Player[] getPlayers() {
        return players;
    }
    public Bag getBag() {
        return bag;
    }


    /**
     * Calculates who has the turn to play
     * @return the player who plays in this turn
     */
    public static Player whoPlays() {
        return null;
    }


    /**
     * Calculates if we have a winner
     * @return the player who is the winner and in case we don't have a winner returns null
     */
    public static Player winner() {
        return null;
    }


    /**
     * Save game
     */
    public void saveGame() {}


    /**
     * Load saved game
     */
    public void loadGame() {}

}
