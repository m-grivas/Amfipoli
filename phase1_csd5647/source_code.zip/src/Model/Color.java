package Model;

public enum Color {
    BLUE,
    BROWN,
    RED,
    GREEN,
    YELLOW,
    PURPLE
}
