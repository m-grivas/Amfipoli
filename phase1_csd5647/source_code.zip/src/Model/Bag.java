package Model;

import Model.Tiles.Tile;

public class Bag {
    Tile[] tiles = new Tile[125];


    /**
     * Fill the bag with the corresponding tiles from each category
     */
    public Bag() {}

    /**
     * Function to pick a random tile from the bag
     * @return returns a random tile
     */
    public Tile pickTile() {return null;}

    /**
     * Check if bag is empty
     * @return : boolean value if bag is empty
     */
    public boolean checkIfEmpty() {return false;}
}
