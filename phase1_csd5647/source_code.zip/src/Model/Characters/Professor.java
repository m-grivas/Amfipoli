package Model.Characters;

import Model.Color;

public class Professor extends Character {


    /**
     * Create a new character with a usable ability
     *
     * @param c
     */
    public Professor(Color c) {
        super(c);
    }

    /**
     * Picks a tile from each area except the one the player choose earlier at his turn
     */
    @Override
    public void useAbility() {

    }

    @Override
    public void setColor(Color c) {

    }
}
