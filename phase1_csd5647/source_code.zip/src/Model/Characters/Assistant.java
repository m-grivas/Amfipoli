package Model.Characters;

import Model.Color;

public class Assistant extends Character {


    /**
     * Create a new character with a usable ability
     *
     * @param c
     */
    public Assistant(Color c) {
        super(c);
    }

    /**
     * Picks 1 tile form whatever area
     */
    @Override
    public void useAbility() {

    }

    @Override
    public void setColor(Color c) {

    }
}
