package Model.Characters;

import Model.Color;

public class Archeologist extends Character {

    /**
     * Create a new character with a usable ability
     *
     * @param c
     */
    public Archeologist(Color c) {
        super(c);
    }

    /**
     * Picks 2 tiles from whatever area except the one the player choose earlier at his turn
     */
    @Override
    public void useAbility() {

    }

    @Override
    public void setColor(Color c) {

    }
}
