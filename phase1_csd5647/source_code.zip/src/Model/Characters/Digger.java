package Model.Characters;

import Model.Color;

public class Digger extends Character {

    /**
     * Create a new character with a usable ability
     *
     * @param c
     */
    public Digger(Color c) {
        super(c);
    }

    /**
     * Picks at most 2 tiles from the area that the player choose earlier at his turn
     */
    @Override
    public void useAbility() {

    }

    @Override
    public void setColor(Color c) {

    }
}
