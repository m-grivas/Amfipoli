package Model.Characters;

import Model.Color;
import Model.Colored;

/**
 * Character is the abstract class for all characters
 *
 */
public abstract class Character implements Colored {

    /**
     * The color matching the players colors for dealing
     */
    private Color color;

    /**
     * Whether the character ability can be used or not
     */
    private boolean usable;

    /**
     * Create a new character with a usable ability
     */
    public Character(Color c) {
        this.usable = true;
        this.color = c;
    }

    /**
     *
     * @return the color of the character card
     */
    public Color getColor() {
        return this.color;
    }

    /**
     *
     * @return ability status
     */
    public boolean getAvailability() {
        return this.usable;
    }

    /**
     * Implemented by each character subclass
     */
    public abstract void useAbility();
}
