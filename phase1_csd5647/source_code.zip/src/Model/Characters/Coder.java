package Model.Characters;

import Model.Color;

public class Coder extends Character {

    /**
     * Create a new character with a usable ability
     *
     * @param c
     */
    public Coder(Color c) {
        super(c);
    }

    /**
     * Chooses an area and at his next turn he picks 2 tiles from that area
     */
    @Override
    public void useAbility() {

    }

    @Override
    public void setColor(Color c) {

    }
}
